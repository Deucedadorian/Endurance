/* timerb.lib sample application

	Generic TIMERB library use
	Support the following:
		1. periodic call to user routine every timer int
		2.	supports times from about 50us to 1500 seconds with 11.0592mHz xtal (22.1 clock)
		Interrupts faster than 20,000/sec start to become too much overhead for use
	TimerBinit() must be called to initialize the ISR
		uses BIOS freq_divider unless XTAL_FREQ is set to freq in hz
	Calls user-supplied function root nodebug void TimerBRoutine()
		if FAST_TIMERB is defined, only, hl,de,a,f are saved in ISR and TimerBRoutine
			must be asm code that save any regs it uses
Author: Scott Henion
Company: SHDesigns 				Web: http://www.shdesigns.org
*/

/* define this to use asm user function ISR. READ NOTES ON FAST_TIMERB
 asm version handles 40us rate on 22.1mhz board
 'c' version handles 50us
 anything lower than 100us, really slows everything down and
 if too fast, the watchdog timer resets board
 really should use asm if <250us */
#define TIMER_DEBUG
#define FAST_TIMERB
// define this if you want to include multi-second delays.
//#define TEST_LONG
#define TEST_ONE_SHOT
void TimerBRoutine();
//#define XTAL_FREQ 22120000

//#define this to use the network debugger
#define USE_NET_DEBUG

#ifdef USE_NET_DEBUG
#define TCPCONFIG 5	// 8.x and later
// these are for 7.x compilers
//#define MY_IP_ADDRESS "10.1.1.80"
//#define MY_NETMASK "255.255.255.0"
// default is 600, speed up but less then 1500
#define ETH_MTU 700
// reduce size to save RAM
#define UDP_BUF_SIZE 2048
#define TCP_BUF_SIZE 2048
#define MAX_UDP_SOCKET_BUFFERS 4
#define MAX_TCP_SOCKET_BUFFERS 4
#define MAX_SOCKETS 6
#define SOCK_BUF_SIZE 1024
#define MAXBUFS 10
#use "DCRTCP.LIB"
#use "UDPDebug.lib"

// reroute printf to debug_printf
#define printf dbg_printf
//#define putchar(c) dbg_printf("%c",c)
#define kbhit dbg_kbhit
#define getchar dbg_getchar
#endif

#use "timerb.lib"

unsigned long counter;
//unsigned long mycount;
unsigned long last_mstimer;
long looptime;
int counterrun;

// calc ints/sec
void show_counter()
{
	char lbuff[80];
	if (counter)		// prevent divide by 0
		printf("counter=%lu T=%lu us\r\n",counter,(last_mstimer-_timerb_start)*1000l/counter);
	if (counter>2000000)
	{
		counter=0;	// reset counter to prevent overflow
		_timerb_start=MS_TIMER;
	}
}


int init_timer(unsigned long ussec)
{
	float actual;
	if (ussec>4000000l)
		looptime=5000l;
	else
		looptime=1000l;
	printf("Timer init at %ld usec\n",ussec);
	counter=0;
	// start on next rtc timer tick
	if (TimerBInit(ussec,2))		// 10 ms, highest priority
	{
		counterrun=0;
		printf("Invalid value, timer not started.\n");
		return 1;
	}
	actual=TimerBRate();
	printf("Actual Timer ints are: %f usec err=%f%%\n",actual,
	100.0*(actual-(float)ussec)/(float)ussec);
	counterrun=1;
	return 0;
}

/*

		user 'C' or asm routines go  here, make them quick!!
*/
#ifdef FAST_TIMERB
// this is fast asm version
// if we use anything other than HL,DE,AF: WE MUST SAVE IT
// we cant call any 'C' functions, unless we save EVERYTHING, but
// the idea hear is to be real fast and exit, so avoid 'C' overhead
// routine below uses and save bc (could have used DE with no save) but
// this is example
#asm root nodebug
TimerBRoutine::
	ld	hl,(counter)
	inc hl
	ld (counter),hl
	bool	hl
	jr nz,no_countc
	ld	hl,(counter+2)
	inc	hl
	ld (counter+2),hl
no_countc:
	ld	hl,(MS_TIMER)
	ld (last_mstimer),hl
	ld	hl,(MS_TIMER+2)
	ld (last_mstimer+2),hl

	// toggle LED
	ld	a,2
	ld	hl,PEDRShadow
	add a,(hl)
	ld (hl),a
	or	1
	ioi ld (PEDR),a
	and	0feh
	ioi ld (PEDR),a
	ret
#endasm
#else
// normal, slower 'c' function
// all regs are saved, try to be real small here if lots of ints.
nodebug root void TimerBRoutine()
{
	counter++;
	last_mstimer=MS_TIMER;
	WrPortI(PEDR, NULL, PEDRShadow+=2);
}
#endif

void init_leds()
{
// copied form toggled.c
	/*  1. Convert the I/O ports.  Disable slave port which makes
	 *     Port A an output, and PORT E not have SCS signal.
	 */
	WrPortI(SPCR, & SPCRShadow, 0x84);

	/*  2. Read function shadow and set PE1 and PE7 as normal I/O.
	 *     LED's are conencted to PE1 and PE7, make them outputs.
	 *     Using shadow register preserves function of other Port E bits.
	 */
	WrPortI(PEFR,  & PEFRShadow,  ~((1<<7)|(1<<1)) & PEFRShadow);
	WrPortI(PEDDR, & PEDDRShadow, PEDRShadow|(1<<7)|(1<<1));

	/*  3. Turn on DS2 (1 -> PE1) and turn off DS3 (0 -> PE7).
	 */
	WrPortI(PEDR, & PEDRShadow, 2);
}
const unsigned long int ustab[]={
									755,1510,
#ifdef TEST_LONG
									5000000l,1000000l,500000l,250000l,100000l,
									50000l,25000l,
#endif
									10000l,5000l,2000l,
									1000l,  // first test is 1ms
									500l,250l,125l,50l,
#ifdef FAST_TIMERB
									40l,
// will not work if debugger (RST 28) enabled
#if DEBUG_RST==0
									25l,20l,15l,
#endif
#endif
									// test out of bounds vals for 11mhz xtal
									10l,1554000000l,
									185000l // last is 185ms from msg board ;-)
									};

main()
{
	int i,j;
	int reinit;
   unsigned long ipaddr;
#ifdef USE_NET_DEBUG
	dbg_init(0);	// make sure it is not redirected at boot
#endif
	reinit=1;
	counterrun=0;
	i=-1;
	init_leds();
	//init_timer(ustab[i]);	// run first test
#ifdef USE_NET_DEBUG
	printf("Network init.\r\n");
	sock_init();
	while (ifpending(IF_ETH0)&1)
   	tcp_tick(NULL);
   ifconfig(IF_ETH0,IFG_IPADDR,&ipaddr,IFS_END);
   printf("IP addr=%lX\n",ipaddr);
	dbg_init(1);
#endif
	printf("Crystal freq = %ld \n",XTAL_FREQ);
	while (1)
	{
		costate
		{
			// press s2 to go to next test
			if (kbhit()/*||((RdPortI(PBDR)&0x4)==0)*/)	// s1 pressed
			{
				if (kbhit())
					getchar();
				reinit=1;
//				while	((RdPortI(PBDR)&0x4)==0) // wait for release of S1
//					waitfor(DelayMs(5));
			}
			waitfor(DelayMs(50)); // poll switch 200/sec or so
		}
		costate
		{
				if (reinit)
				{
					reinit=0;
					TimerBUninit();		// important to un-init before restarting
					if (++i==(sizeof(ustab)/sizeof(unsigned long)))
						i=0;	// redo test
					init_timer(ustab[i]);	// run current test
				}
				waitfor(DelayMs(looptime));
				show_counter();			// 1st call init ctr
#ifdef TEST_ONE_SHOT
				if (ustab[i]>=1000000l)
				{
					if (counter)
					{
					TimerBUninit();		// important to un-init before restarting
					init_timer(ustab[i]);	// run current test
					}
				}
#endif
		}
#ifdef USE_NET_DEBUG
		costate
		{
			debug_tick();
		}
#endif
	}
}

//#nodebug