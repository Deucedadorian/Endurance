// for some reason I always se powers of 2 for buffer sizes, MALLOC_SIZE can be any size
// as long as there is plenty of root data space.
#define MALLOC_SIZE 1024
#define MALLOC_DEBUG
#use malloc.lib
/*

malloc test program. The malloc code was taken from the K&R 'C' book. They were
modified to add some debugging support.

Embedded systems are ususally designed to NOT use malloc()/free(). Embedded
systems have limited resources. It is always best to allocate all data at
compile time. Thus no run-time problems will occur. Also, allocation adds
overhead to data and execution speed.

Sometimes you just really want to use malloc(). It is up to the developer to
guarantee that enough memory is ALWAYS available. Or, at lest to handle
the case when no free memory is available.

Always build with MALLOC_DEBUG defined while developing and testing. It will
verify that your code does not corrupt memory buffers. Production builds
should not use the define (adds a bit more memory effeciency and speed.)

Use the MALLOC_SIZE #define to specify the amount of memory to use. This
memory is located in root data space, so it should not be too large. My testing
shows about 24k will eat up all root data area (I have modified the bios
root data size for one of my apps.) Most applications should be fine
with only a few k. The default is 2048 if MALLOC_SIZE is not defined.

Also, even though malloc_avail() may report free memory, it may be fragmented
into small blocks and a malloc() may still fail.

This example demonstrates the use of malloc and free. Also it will purposely
corrupt 2 allocated blocks to test the debugging features. Corrupted memory blocks are
not returned to the free memory pool. This is to prevent furter corruption of the free
list.

I hope you find these useful :-)

Scott Henion. www.shdesigns.org

Report bugs to:
shenion@shdesigns.org

Guarantee:
Use with care, this software has been debugged, but is only guaranteed to use
memory and disk space. Nothing more is implied. Use at your own risk.
*/

char * buffs[10];
int sizes[10];
main()
{
	float frand;
	int i,memsize;
	printf("Available malloc() memory - %d\n",malloc_avail());
	for (i=0;i<10;i++)
	{
		frand=rand()*100;
		memsize=(int)frand+50;
		printf("Allocating %d bytes..",memsize);
		buffs[i]=(char *)malloc(memsize);
		sizes[i]=memsize;
		if (buffs[i]!=NULL)
			printf("Sucess! address=%x",buffs[i]);
			else
			printf("Failed :-(");
		printf(" - %d bytes available\n",malloc_avail());
	}
#ifdef MALLOC_DEBUG
	// corrupt the 2nd and third memory entries
	printf("Test! corrumpting buffer for buffers at %x and %x\n",buffs[1],buffs[2]);
	*(	buffs[1]-1)='X';
	strcpy(buffs[2]+sizes[2],"XYZZY");
#endif
	// // now try freeing memory
	for (i=0;i<10;i++)
		if (buffs[i]!=NULL)
		{
			printf("Freeing %d bytes.",sizes[i]);
			free(buffs[i]);
			printf(".Avail now: %d\n",malloc_avail());
		}
}