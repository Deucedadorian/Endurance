#ifndef __UDPDEBUG_LIB
#define __UDPDEBUG_LIB
/* START LIBRARY DESCRIPTION *********************************************
UDPDEBUG.LIB
	Copyright (c) 2002-2003, SHDesigns, www.shdesigns.org

DESCRIPTION:
	UDP Debug console.

SUPPORT LIB'S:
END DESCRIPTION **********************************************************/
int 		debug_init(int ena);
int  	 	debug_kbhit(void);
int  near 	debug_getchar(void);
void near 	debug_putchar(char c);
int 		debug_tick(void);

extern char debug_autocr;
extern FILE debug_stdio[1];
#endif
