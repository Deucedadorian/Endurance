#if !defined(AFX_SETIPDLG_H__6ADAF745_54F9_438F_A402_6B243086F152__INCLUDED_)
#define AFX_SETIPDLG_H__6ADAF745_54F9_438F_A402_6B243086F152__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SetIPDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSetIPDlg dialog

class CSetIPDlg : public CDialog
{
// Construction
public:
	void DoDHCPChange();
	CSetIPDlg(CWnd* pParent = NULL);   // standard constructor
	DWORD m_IPAddress,m_Gateway,m_Netmask;
// Dialog Data
	//{{AFX_DATA(CSetIPDlg)
	enum { IDD = IDD_SET_IP };
	CIPAddressCtrl	m_NetmaskCtl;
	CIPAddressCtrl	m_IPAddressCtl;
	CIPAddressCtrl	m_GatewayCtl;
	int		m_use_dhcp;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetIPDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	
	// Generated message map functions
	//{{AFX_MSG(CSetIPDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnUseDhcp();
	afx_msg void OnUseDhcp2();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETIPDLG_H__6ADAF745_54F9_438F_A402_6B243086F152__INCLUDED_)
