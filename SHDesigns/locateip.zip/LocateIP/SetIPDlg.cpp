// SetIPDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LocateIP.h"
#include "SetIPDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSetIPDlg dialog


CSetIPDlg::CSetIPDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetIPDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSetIPDlg)
	m_use_dhcp = -1;
	//}}AFX_DATA_INIT
}


void CSetIPDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetIPDlg)
	DDX_Control(pDX, IDC_NETMASK, m_NetmaskCtl);
	DDX_Control(pDX, IDC_IPADDRESS, m_IPAddressCtl);
	DDX_Control(pDX, IDC_GATEWAY, m_GatewayCtl);
	DDX_Radio(pDX, IDC_USE_DHCP, m_use_dhcp);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSetIPDlg, CDialog)
	//{{AFX_MSG_MAP(CSetIPDlg)
	ON_BN_CLICKED(IDC_USE_DHCP, OnUseDhcp)
	ON_BN_CLICKED(IDC_USE_DHCP2, OnUseDhcp2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetIPDlg message handlers

void CSetIPDlg::DoDHCPChange()
{
#ifndef VERSION2
	int enable=(m_use_dhcp==0)?0:1;
	((CEdit *)GetDlgItem(IDC_NETMASK))->EnableWindow(enable);
	((CEdit *)GetDlgItem(IDC_IPADDRESS))->EnableWindow(enable);
	((CEdit *)GetDlgItem(IDC_GATEWAY))->EnableWindow(enable);
#endif
}

BOOL CSetIPDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_IPAddressCtl.SetAddress(m_IPAddress);
	m_GatewayCtl.SetAddress(m_Gateway);
	m_NetmaskCtl.SetAddress(m_Netmask);
	DoDHCPChange();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSetIPDlg::OnUseDhcp() 
{
	m_use_dhcp=0;
	DoDHCPChange();
}

void CSetIPDlg::OnUseDhcp2() 
{
	m_use_dhcp=1;
	DoDHCPChange();
	
}

void CSetIPDlg::OnOK() 
{
	m_IPAddressCtl.GetAddress(m_IPAddress);
	m_GatewayCtl.GetAddress(m_Gateway);
	m_NetmaskCtl.GetAddress(m_Netmask);
	
	CDialog::OnOK();
}
