// LocateIPDlg.h : header file
//

#if !defined(AFX_LOCATEIPDLG_H__989A3615_D02A_4CC7_90B4_C352866D97B5__INCLUDED_)
#define AFX_LOCATEIPDLG_H__989A3615_D02A_4CC7_90B4_C352866D97B5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
/////////////////////////////////////////////////////////////////////////////
// CLocateIPDlg dialog
#include <afxtempl.h>

class CLocateIPDlg : public CDialog
{
// Construction
public:
	int SearchTimer;
	bool InitSearch;
	bool SockInit;
	CAsyncSocket UDPSock;
	LRESULT IdleProc(WPARAM wparam, LPARAM lCount);
	CLocateIPDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CLocateIPDlg)
	enum { IDD = IDD_LOCATEIP_DIALOG };
	CString	m_Results;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLocateIPDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	CArray<MAC_ADDR,MAC_ADDR &> mac_addrs;
	// Generated message map functions
	//{{AFX_MSG(CLocateIPDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSearch();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnConfigure();
	afx_msg void OnHelp();
	afx_msg void OnTest();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOCATEIPDLG_H__989A3615_D02A_4CC7_90B4_C352866D97B5__INCLUDED_)
