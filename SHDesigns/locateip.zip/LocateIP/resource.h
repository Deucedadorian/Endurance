//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LocateIP.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_LOCATEIP_DIALOG             102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDS_HELP                        104
#define IDR_MAINFRAME                   128
#define IDD_SET_IP                      129
#define IDD_SELECT_MAC                  130
#define IDC_RESULTS                     1000
#define IDC_SEARCH                      1001
#define IDC_USE_DHCP                    1002
#define IDC_USE_DHCP2                   1003
#define IDC_IP1                         1004
#define IDC_IP2                         1005
#define IDC_CONFIGURE                   1005
#define IDC_IP3                         1006
#define IDC_IP4                         1007
#define IDC_MAC_LIST                    1007
#define IDC_MASK1                       1008
#define IDC_MASK2                       1009
#define IDC_MASK3                       1010
#define IDC_MASK4                       1011
#define IDC_GW1                         1012
#define IDC_GW2                         1013
#define IDC_GW3                         1014
#define IDC_GW4                         1015
#define IDC_HELPB                       1018
#define IDC_IPADDRESS                   1034
#define IDC_NETMASK                     1035
#define IDC_GATEWAY                     1036

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
