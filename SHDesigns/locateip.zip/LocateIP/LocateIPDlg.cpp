// LocateIPDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LocateIP.h"
#include "LocateIPDlg.h"
#include "SelectMacDlg.h"
#include "SetIPDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLocateIPDlg dialog

CLocateIPDlg::CLocateIPDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLocateIPDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLocateIPDlg)
	m_Results = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	InitSearch=SockInit=false;
	SearchTimer=0;
}

void CLocateIPDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLocateIPDlg)
	DDX_Text(pDX, IDC_RESULTS, m_Results);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CLocateIPDlg, CDialog)
	//{{AFX_MSG_MAP(CLocateIPDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_SEARCH, OnSearch)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_CONFIGURE, OnConfigure)
	ON_BN_CLICKED(IDC_HELPB, OnHelp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLocateIPDlg message handlers

BOOL CLocateIPDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	SetTimer(1,100,NULL);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CLocateIPDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CLocateIPDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CLocateIPDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CLocateIPDlg::OnSearch() 
{
	char buff[100];
	int flag=1;
	int ret=SOCKET_ERROR,retry=20;
	CString tmp,address;
	UINT port;

	buff[0]=0;
	m_Results="";
	mac_addrs.RemoveAll();
	strcpy(buff+1,"Request ID from ");
	gethostname(buff+1+strlen(buff+1),80);
	SearchTimer=50;	
	if (!SockInit)
		UDPSock.Create(0,SOCK_DGRAM);
	UDPSock.GetSockName(address,port);
	tmp.Format("Using address %s, port %d to find remote boards.\r\n",address,port);
	m_Results+=tmp;
	UpdateData(FALSE);

	UDPSock.SetSockOpt(SO_BROADCAST, &flag, sizeof(int));
	while ((UDPSock.SendTo(buff,strlen(buff+1)+2,LOCATE_PORT,NULL)==SOCKET_ERROR)&&
		(GetLastError()==WSAEWOULDBLOCK))
		Sleep(100);
	SockInit=true;
}


void CLocateIPDlg::OnTimer(UINT nIDEvent) 
{
	char buff[1500];
	UINT port;
	CString address,tmp;
	int ret;
	if (!InitSearch)
	{
		OnSearch();
		InitSearch=true;
	}
	if (SockInit)
	{
		ret=UDPSock.ReceiveFrom(buff,1500,address,port);
		// byte 0 is command 
		// bytes 1-6 is MAC_ADDR struct
		if (ret>=0)
		{
			switch (buff[0])
			{
			case 0:
				buff[ret]='\0'; // make sure string is terminated
				MAC_ADDR resp;
				memcpy(&resp,buff+1,sizeof(MAC_ADDR));
				strcpy(resp.Address,address);
				tmp.Format("Response from %s: %s\r\n",LPCSTR(address),resp.ID_String);
				m_Results+=tmp;
				tmp.Format("    Mac addr: %02x:%02x:%02x:%02x:%02x:%02x\r\n",
					resp.addr[0]&0xff,
					resp.addr[1]&0xff,
					resp.addr[2]&0xff,
					resp.addr[3]&0xff,
					resp.addr[4]&0xff,
					resp.addr[5]&0xff);
				m_Results+=tmp;
#ifdef VERSION2
				if (resp.params.use_dhcp)
#else
				if (resp.params.ip_address==0)
#endif
				{
					m_Results+="    (Using DHCP)\r\n";
				}
#ifndef VERSION2
				else
#endif
				{
					tmp.Format("    Mask = %2d:%2d:%2d:%2d\r\n",
						0xff&(resp.params.netmask>>24),
						0xff&(resp.params.netmask>>16),
						0xff&(resp.params.netmask>>8),
						0xff&(resp.params.netmask));
					m_Results+=tmp;
					tmp.Format("    Gateway = %2d:%2d:%2d:%2d\r\n",
						0xff&(resp.params.gateway>>24),
						0xff&(resp.params.gateway>>16),
						0xff&(resp.params.gateway>>8),
						0xff&(resp.params.gateway));
					m_Results+=tmp;
				}
				mac_addrs.Add(resp);
				UpdateData(FALSE);
				break;
			case 1:
				tmp.Format("Board at MAC addr: %02x:%02x:%02x:%02x:%02x:%02x reconfigured\r\n   (Board will reset with new parameters)\r\n",
					buff[1]&0xff,buff[2]&0xff,buff[3]&0xff,buff[4]&0xff,buff[5]&0xff,buff[6]&0xff);
				m_Results+=tmp;
				UpdateData(FALSE);
				break;
			}
		
		}
		if ((SearchTimer)&&(--SearchTimer==0))
		{
	
			m_Results+="Search Complete\r\n";
			UpdateData(FALSE);
		}
	}
	CDialog::OnTimer(nIDEvent);
}

void CLocateIPDlg::OnConfigure() 
{
	int boardnum=0;
	CSelectMacDlg dlg;
	if (mac_addrs.GetSize()==0)
	{
		AfxMessageBox("No boards found.\r\nUse search to find boards first",MB_OK);
		return;
	}
	if (mac_addrs.GetSize()>1)
	{
		CString tmp;
		for (int i=0;i<mac_addrs.GetSize();i++)
		{
		tmp.Format("#%d - %02x:%02x:%02x:%02x:%02x:%02x - %s",i+1,
			mac_addrs[i].addr[0]&0xff,
			mac_addrs[i].addr[1]&0xff,
			mac_addrs[i].addr[2]&0xff,
			mac_addrs[i].addr[3]&0xff,
			mac_addrs[i].addr[4]&0xff,
			mac_addrs[i].addr[5]&0xff,
			mac_addrs[i].ID_String);
		dlg.m_MAC_List.Add(tmp);
		}
		if (dlg.DoModal()!=IDOK)
			return;
		boardnum=dlg.m_MACNum;
	}
	CSetIPDlg IPDlg;
	IPDlg.m_IPAddress=mac_addrs[boardnum].params.ip_address;
	IPDlg.m_Netmask=mac_addrs[boardnum].params.netmask;
#ifdef VERSION2
	IPDlg.m_use_dhcp=mac_addrs[boardnum].params.use_dhcp==0; //0=use DHCP
#else
	if (mac_addrs[boardnum].params.ip_address==0)
		IPDlg.m_use_dhcp=0;	// 0 is use dhcp, 1 is manual
	else
		IPDlg.m_use_dhcp=1;	// 0 is use dhcp, 1 is manual
#endif
	IPDlg.m_Gateway=mac_addrs[boardnum].params.gateway;
	if (IPDlg.DoModal()==IDOK)
	{
		int flag=1;
		char buff[80];
#ifdef VERSION2
		mac_addrs[boardnum].params.use_dhcp=IPDlg.m_use_dhcp==0;
#else
		if (IPDlg.m_use_dhcp==0)
			mac_addrs[boardnum].params.ip_address=0;	// 0 is use dhcp, 1 is manual
		else
#endif
			mac_addrs[boardnum].params.ip_address=IPDlg.m_IPAddress;
		mac_addrs[boardnum].params.netmask=IPDlg.m_Netmask;
		mac_addrs[boardnum].params.gateway=IPDlg.m_Gateway;
		UDPSock.SetSockOpt(SO_BROADCAST, &flag, sizeof(int));
		buff[0]=1;
		memcpy(buff+1,&mac_addrs[boardnum].addr,sizeof(mac_addrs[boardnum].addr));
		memcpy(buff+1+sizeof(mac_addrs[boardnum].addr),&mac_addrs[boardnum].params,sizeof(mac_addrs[boardnum].params));
		while ((UDPSock.SendTo(buff,1+sizeof(mac_addrs[boardnum].addr)+sizeof(mac_addrs[boardnum].params),LOCATE_PORT,NULL)==SOCKET_ERROR)&&
			(GetLastError()==WSAEWOULDBLOCK))
			Sleep(100);
	}
}

void CLocateIPDlg::OnHelp() 
{

	AfxMessageBox(IDS_HELP,MB_OK|MB_ICONQUESTION);
}

