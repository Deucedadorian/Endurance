// SelectMacDlg.cpp : implementation file
//

#include "stdafx.h"
#include "locateip.h"
#include "SelectMacDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSelectMacDlg dialog


CSelectMacDlg::CSelectMacDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSelectMacDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSelectMacDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSelectMacDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSelectMacDlg)
	DDX_Control(pDX, IDC_MAC_LIST, m_MACList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSelectMacDlg, CDialog)
	//{{AFX_MSG_MAP(CSelectMacDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSelectMacDlg message handlers

BOOL CSelectMacDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	for (int i=0;i<m_MAC_List.GetSize();i++)
		m_MACList.AddString(m_MAC_List.GetAt(i));
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSelectMacDlg::OnOK() 
{
	m_MACNum=m_MACList.GetCurSel();	
	CDialog::OnOK();
}
