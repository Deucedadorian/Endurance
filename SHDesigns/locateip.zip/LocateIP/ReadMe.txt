========================================================================
       MICROSOFT FOUNDATION CLASS LIBRARY : LocateIP
========================================================================

LocateIP searches for Rabbit based boards that include the sample code in .\rabbitcode

The code works as follows:

1	LocateIP sends a UDP broadcast packet to port 9999 with first byte==0;
	The rest of the UDP packet is a text string "hostname"
	This is not needed, the rabbit board just prints it to SDTIO.

2.	Rabbit board fills in the new_params struct with its parameters.

3.	The Rabbit board fills a UDP packet with its MAC address, and the params

4.	The Rabbit sends a broadcast packet to the source port that did the request.

5.	LocateIP receives MAC address and parameters and shows them in the list.

6.	After 5 seconds, LocateIP stops listening for responses.

The configure does the following:

1.	LocateIP checks how many rabbit boards have responded. If only one, then
	it uses that address. If more then one, a dialog is used to select the board.

2.	The IP params can be edited with a dialog box

3.	LocateIP builds an IP packet as follows:
	byte 0 - 1
	bytes 1-6 - MAC address
	bytes 7-n - new_params struct

4.	The rabbit board receives the UDP packet and updates its new_params struct;
	Note: THIS IS IMPORTANT, it makes sure the MAC address is correct. ALL RABBIT
	BOARDS will receive the configure packet. So they must verify it first.

5.	The rabbit board send back the packet to locatip as ann acknowledge
	which is displayed.

6.	The parameters are saved in FLASH (userblock)

7.	The Rabbit board resets with the new params after 5 seconds.

Note on broadcast packets:

Broadcast packets are required since the destination IP address is unknown. Also, the
 boards IP address may be unreachable. FOr example:

 PC at 192.168.1.2 with a netmask of 255.255.255.0
 Rabbit at 10.1.1.50 with a netmask of 255.255.255.0

Neither the PC or the rabbit could send packets addressed to either board. They would get
 "Destination unreachable" because their network stacks would assume the other is NOT
 on their local subnet and would look elsewhere.

Ok, so we use broadcasts, that will work within the local subnet. So both the rabbit
board and the PC must be on the same subnet.

Now we send the new parameters as a broadcast packet also. So ALL rabbit boards
(actually Everything on the subnet) receive the packet. So the rabbit boards
must check the MAC address with its own, if it is different it ignores it. Hopefully,
no PC or network box is using UDP port 9999. Not likely anyway.

Note: the example code now is for the Version 2 code and uses port 9998. use the
executable in the LocateIP___Win32_ReleaseV2 directory.

The Rabbit code is located in the .\RabbitCode directory.

-------------------------------- MFC readme ------------------------------------

This file contains a summary of what you will find in each of the files that
make up your LocateIP application.

LocateIP.dsp
    This file (the project file) contains information at the project level and
    is used to build a single project or subproject. Other users can share the
    project (.dsp) file, but they should export the makefiles locally.

LocateIP.h
    This is the main header file for the application.  It includes other
    project specific headers (including Resource.h) and declares the
    CLocateIPApp application class.

LocateIP.cpp
    This is the main application source file that contains the application
    class CLocateIPApp.

LocateIP.rc
    This is a listing of all of the Microsoft Windows resources that the
    program uses.  It includes the icons, bitmaps, and cursors that are stored
    in the RES subdirectory.  This file can be directly edited in Microsoft
	Visual C++.

LocateIP.clw
    This file contains information used by ClassWizard to edit existing
    classes or add new classes.  ClassWizard also uses this file to store
    information needed to create and edit message maps and dialog data
    maps and to create prototype member functions.

res\LocateIP.ico
    This is an icon file, which is used as the application's icon.  This
    icon is included by the main resource file LocateIP.rc.

res\LocateIP.rc2
    This file contains resources that are not edited by Microsoft 
	Visual C++.  You should place all resources not editable by
	the resource editor in this file.




/////////////////////////////////////////////////////////////////////////////

AppWizard creates one dialog class:

LocateIPDlg.h, LocateIPDlg.cpp - the dialog
    These files contain your CLocateIPDlg class.  This class defines
    the behavior of your application's main dialog.  The dialog's
    template is in LocateIP.rc, which can be edited in Microsoft
	Visual C++.


/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named LocateIP.pch and a precompiled types file named StdAfx.obj.

Resource.h
    This is the standard header file, which defines new resource IDs.
    Microsoft Visual C++ reads and updates this file.

/////////////////////////////////////////////////////////////////////////////
Other notes:

