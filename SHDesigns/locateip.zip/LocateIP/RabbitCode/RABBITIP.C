/*******************************************************************************
        rabbitip.c

   Copyright 2002-2006 SHDesigns www.shdesigns.org
*******************************************************************************/
/*
*** no warrantee, this software is only guaranteed to take up disk space. Nothing more.

These parameters are the default values used if dhcp is not present.
 */
#define USE_DHCP
#define TCPCONFIG 6
// saves a bit of code, comment out if DNS used.
#define DISABLE_DNS
//#define MY_IP_ADDRESS   "0.0.0.0"
//#define MY_NETMASK      "255.255.255.0"

// use 9998 for the LocateIP___Win32_ReleaseV2/LocateIP.exe program
// do not use the one in the release dir
#define LOCAL_UDP_PORT	9998
// default is 600, speed up but less then 1500
#define ETH_MTU 700
// this may help realtek problems
//#define FULL_DUPLEX
// reduce size to save RAM
#define UDP_BUF_SIZE 512
#define TCP_BUF_SIZE 2048
#define MAX_UDP_SOCKET_BUFFERS 2
#define MAX_TCP_SOCKET_BUFFERS 3
#define MAX_SOCKETS 2
#define SOCK_BUF_SIZE 1024
#define MAXBUFS 5
/********************************
 * End of TCP/IP configuration section *
 ********************************/

#define ID_STRING "XYZ corp Rabbit Board"
/*
 * Force everything into xmem, and import the TCP/IP lib.
 */
#memmap xmem
#use "dcrtcp.lib"

//run-time variables copied to flash
typedef struct
{
	unsigned long ip_address;
	unsigned long netmask;
	unsigned long gateway;
   char use_dhcp;
	unsigned long valid_flag;
} RTDATA;

typedef struct
{
	char new;
	unsigned long ip_address;
	unsigned long netmask;
	unsigned long gateway;
   char use_dhcp;
} NEW_PARAMS;

//
// global variables
//
RTDATA RTData;				// data backed up in flash
NEW_PARAMS new_params;	// updated params
udp_Socket udpsock;		// udp socket handle

const RTDATA RT_Defaults={
	0x00000000l,	// could be real ip, 0 says use DHCP
	0xffffff00l,	// class c netmask
	0l,			// no gateway;
   1,				// use DHCP
	0x55aaface	// valid adata flag
};

void init_defaults()
{
	RTData=RT_Defaults;
	writeUserBlock(0,(void *)&RTData,sizeof(RTData));
}

/* receive one UDP packet */
int receive_packet(void)
{
	static char buf[128];
	static char addr[8];
	longword ip;
	word port;
	#GLOBAL_INIT
	{
		memset(buf, 0, sizeof(buf));
	}

	/* receive the packet */
	if (-1 == udp_recvfrom(&udpsock, buf, sizeof(buf),&ip,&port)) {
		/* no packet read. return */
		return 0;
	}
	switch (buf[0])
	{
	case	0: // get params
		printf("Received UDP identify from %s at ip %d.%d.%d.%d port %d\n",buf+1,
		(int)(ip>>24)&0xff,(int)(ip>>16)&0xff,(int)(ip>>8)&0xff,(int)(ip&0xff),port);
		pd_getaddress(0,addr);
		memcpy(buf+1,addr,6);						// put in our MAC address
		new_params.ip_address=RTData.ip_address;	// update new_params
		new_params.netmask=RTData.netmask;
		new_params.gateway=RTData.gateway;
		new_params.use_dhcp=RTData.use_dhcp;

		memcpy(buf+7,&new_params,sizeof(new_params));
		strcpy(buf+7+sizeof(new_params),ID_STRING);

		udp_sendto(&udpsock,buf,7+sizeof(new_params)+strlen(ID_STRING),-1,port);	// broadcast back to source port
		break;
	case	1:	// set params
		pd_getaddress(0,addr);
		if (memcmp(addr,buf+1,6)==0)	// !!!MAKE SURE IT IS OUR MAC!!!!
		{
			printf("Received UDP set param from ip %d.%d.%d.%d port %d\n",
				(int)(ip>>24)&0xff,(int)(ip>>16)&0xff,(int)(ip>>8)&0xff,(int)(ip&0xff),port);
			memcpy(&new_params,buf+7,sizeof(new_params));	// update params
			new_params.new=1;	// set new flag (costate will reset with new)
			udp_sendto(&udpsock,buf,7+sizeof(new_params),-1,port); // echo back as an "ack"
		}
		break;
	}
	return 1;
}


root main()
{
	char addr[16];
	char mac_addr[20];
   unsigned long ip_addr;
   int fb;
	new_params.new=0;
   printf("STACKSEG=%x\n",RdPortI(STACKSEG));
	printf("Network init.\n");
	readUserBlock(&RTData,0,sizeof(RTData));	// read data stored in flash
	//
	// if FLASH params are not valid, load default settings
	//
	if (RTData.valid_flag!=0x55aaface)
		init_defaults();
	//
	// init network
	//
	sock_init();
	//
	// if IP address is fixed, disable DHCP
	// if hardcoded, override sock_init() stuff with ours.
	//
	if (RTData.ip_address&&!RTData.use_dhcp)
	{
        printf("Load Static IP settings.\r\n");
        ifconfig(IF_ETH0,IFS_DHCP,0,IFS_END);
        ifconfig(IF_ETH0,IFS_IPADDR,RTData.ip_address,IFS_END);
        if (RTData.netmask)
            ifconfig(IF_ETH0,IFS_NETMASK,RTData.netmask,IFS_END);
        if (RTData.gateway)
            ifconfig(IF_ETH0,IFS_ROUTER_SET,RTData.gateway,IFS_END);
    }
    else
    {
        ifconfig(IF_ETH0,IFS_DHCP,1,IFS_DHCP_TIMEOUT,5,IFS_DHCP_FALLBACK,1,
        IFS_DHCP_FB_IPADDR,RTData.ip_address,IFS_NETMASK,RTData.netmask,IFS_END);
        printf("Using DHCP.\r\n");
    }
   ifconfig(IF_ETH0,IFS_UP,IFS_END);

   while (ifpending(IF_ETH0)&1)
   {
   	tcp_tick(NULL);
   }
   fb=0;
   ifconfig(IF_ETH0,IFG_DHCP_FELLBACK,&fb,IFS_END);
   if (fb||gethostid()==0l)
   {
        ifconfig(IF_ETH0,IFS_DHCP,0,IFS_IPADDR,RTData.ip_address,IFS_END);
        if (RTData.netmask)
            ifconfig(IF_ETH0,IFS_NETMASK,RTData.netmask,IFS_END);
        if (RTData.gateway)
            ifconfig(IF_ETH0,IFS_ROUTER_SET,RTData.gateway,IFS_END);
        ifconfig(IF_ETH0,IFS_UP,IFS_END);
   }
	//
	// FYI show network info
	//
	pd_getaddress(0,addr);
	sprintf(mac_addr,"%02x:%02x:%02x:%02x:%02x:%02x",
		addr[0],addr[1],addr[2],
		addr[3],addr[4],addr[5]);
	printf("MAC addr=%s\n",mac_addr);

	// init udp identify handler
	if(!udp_open(&udpsock, LOCAL_UDP_PORT, -1,-1, NULL))
	{
		printf("udp_open failed!\n");
	}
	printf("IP address is:  %s\n", inet_ntoa( addr, gethostid()));
	printf("Subnet Mask is: %s\n", inet_ntoa( addr, sin_mask));
// this used to work in 7.10, but changed in 7.21, removed
//	printf("Default Gateway is: %s\n", inet_ntoa( addr, _arp_gate_data[0].gate_ip));
// this is the new 7.21 version
   ifconfig(IF_ETH0,IFG_ROUTER_DEFAULT,&ip_addr,IFS_END);
	printf("Default router is: %s\n", inet_ntoa( addr, ip_addr));
	printf("Free xmem=%ld bytes\n",xavail(NULL)); // more FYI stuff
	printf("Startup Complete :-)\n");

	while(1) {
		costate
		{	// tcpip processing
			tcp_tick(NULL); // process non-udp stuff
			receive_packet();
		}
		costate
		{	// process results
			waitfor(DelayMs(500));
			if (new_params.new)
			{
				RTData.ip_address=	new_params.ip_address;
				RTData.netmask=		new_params.netmask;
				RTData.gateway=		new_params.gateway;
            RTData.use_dhcp=		new_params.use_dhcp;
            RTData.valid_flag=0x55aaface; // should already be valid.
				writeUserBlock(0,&RTData,sizeof(RTData));
				new_params.new=0;
				waitfor(DelayMs(5000));
				forceSoftReset();
			}
		}
	}
}