// LocateIP.h : main header file for the LOCATEIP application
//

#if !defined(AFX_LOCATEIP_H__88CE7277_8E71_4E5E_BE46_088DA08A9EE3__INCLUDED_)
#define AFX_LOCATEIP_H__88CE7277_8E71_4E5E_BE46_088DA08A9EE3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CLocateIPApp:
// See LocateIP.cpp for the implementation of this class
//
#ifdef VERSION2
#define LOCATE_PORT 9998
#else
#define LOCATE_PORT 9999
#endif

#pragma pack(1)
typedef struct _new_params
{
	char newf;
	unsigned long ip_address;
	unsigned long netmask;
	unsigned long gateway;
#ifdef VERSION2
	unsigned char use_dhcp;
#endif
} NEW_PARAMS;

typedef struct 
{
	unsigned char addr[6];
	NEW_PARAMS params;
	char ID_String[80];
	char Address[80];
} MAC_ADDR;
#pragma pack()

class CLocateIPApp : public CWinApp
{
public:
	CLocateIPApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLocateIPApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CLocateIPApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOCATEIP_H__88CE7277_8E71_4E5E_BE46_088DA08A9EE3__INCLUDED_)
