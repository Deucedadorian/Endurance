#if !defined(AFX_SELECTMACDLG_H__81AA1F6E_5F4D_4714_A4AB_546AC1464F26__INCLUDED_)
#define AFX_SELECTMACDLG_H__81AA1F6E_5F4D_4714_A4AB_546AC1464F26__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SelectMacDlg.h : header file
//
#include <afxtempl.h>
/////////////////////////////////////////////////////////////////////////////
// CSelectMacDlg dialog

class CSelectMacDlg : public CDialog
{
// Construction
public:
	int m_MACNum;
	CSelectMacDlg(CWnd* pParent = NULL);   // standard constructor
	CArray<CString,CString &> m_MAC_List;
// Dialog Data
	//{{AFX_DATA(CSelectMacDlg)
	enum { IDD = IDD_SELECT_MAC };
	CComboBox	m_MACList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSelectMacDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSelectMacDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SELECTMACDLG_H__81AA1F6E_5F4D_4714_A4AB_546AC1464F26__INCLUDED_)
