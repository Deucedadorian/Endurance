//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UDPDebug.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define ID_STATUSPANE                   105
#define IDR_MAINFRAME                   128
#define IDR_UDPDEBTYPE                  129
#define IDD_IPADDR                      130
#define IDD_DUMPMEM                     131
#define IDD_WATCH                       132
#define IDD_ADDWATCH                    133
#define IDR_WMENU                       134
#define IDD_DELETWATCH                  135
#define IDD_EDITINT                     136
#define IDR_UNUSED                      137
#define IDR_UDPDEBWTYPE                 138
#define IDI_STRUCT                      139
#define IDI_NONE                        141
#define IDI_INT                         142
#define IDI_CHAR                        143
#define IDI_LONG                        144
#define IDD_EDITVAR                     145
#define IDI_STRING                      146
#define IDR_UDPDEBTTYPE                 147
#define IDR_WTOOLBAR                    148
#define IDR_STOOLBAR                    150
#define IDD_DUMPRAM                     152
#define IDC_IP_ADDR                     1000
#define IDC_READ                        1001
#define IDC_MEMDATA                     1003
#define IDC_CHAR                        1008
#define IDC_INT                         1009
#define IDC_LONGINT                     1010
#define IDC_STRING                      1011
#define IDC_STRUCT                      1012
#define IDC_STRUCTLIST                  1013
#define IDC_SLENGTH                     1014
#define ID_UPDATE                       1016
#define IDC_ADDR                        1017
#define IDC_WLIST                       1018
#define IDC_FLOAT                       1019
#define IDC_HEX                         1021
#define IDC_INTVAL                      1022
#define IDC_ADDRESS                     1023
#define IDC_MSIZE                       1024
#define IDC_WORD                        1025
#define IDC_LONG                        1026
#define IDC_WATCHDATA                   1027
#define IDC_DATA                        1028
#define IDC_VNAME                       1030
#define IDC_PROMPT                      1031
#define IDC_SIGNED                      1032
#define IDC_MTYPE                       1034
#define IDC_MTYPE2                      1035
#define IDC_MEM_START                   1035
#define IDC_MTYPE3                      1036
#define IDC_MEM_SIZE                    1036
#define ID_RECONNECT                    32771
#define ID_DUMP                         32772
#define ID_READSYM                      32773
#define ID_ADDW                         32775
#define ID_DELETEW                      32776
#define ID_SAVEW                        32777
#define ID_LOADW                        32778
#define ID_MODIFY                       32779
#define ID_AUTO                         32780
#define ID_READLASTSYM                  32781
#define ID_LOADSTRUCT                   32782
#define ID_LOADLASTSTRUCT               32783
#define ID_NEWWVIEW                     32784
#define ID_LOGFILE                      32787
#define ID_EDITDATA                     32790
#define ID_TIMESTAMP                    32791
#define ID_SHOWSYM                      32792
#define ID_READBSYM                     32799
#define ID_READLASTBSYM                 32800
#define ID_AUTOCR                       32801
#define ID_CLS                          32802
#define IDM_WRAP                        32803
#define IDM_PAUSE                       32804
#define ID_DEF_LIST                     32805
#define IDM_DUMP_RAM                    32806
#define IDM_RESET                       32807

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        153
#define _APS_NEXT_COMMAND_VALUE         32808
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
